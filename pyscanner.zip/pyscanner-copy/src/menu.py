#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
from src.scanner import PortScanner
from src.subdomain_scanner import SubdomainScanner
from src.dns_bruteforce import DNSBruteforce
from src.vulnerability_scanner import VulnerabilityScanner
from src.exploiter import Exploiter
from src.metasploit_integration import MetasploitIntegration
from src.ssh_ftp_bruteforce import SSH_FTP_Bruteforce

class InteractiveMenu:
    def __init__(self):
        self.target = ""
        self.open_ports = []
        self.vulnerabilities = []
        self.login_urls = []
        self.ssh_ftp_targets = []  # Nova lista para SSH/FTP

    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def display_banner(self):
        print("""
    ╔═══════════════════════════════════════╗
    ║             PyScanner v6.0            ║
    ║         PENTEST PROFISSIONAL          ║
    ║                                       ║
    ║        Desenvolvido por whatcomes     ║
    ║                                       ║
    ║  [1] 🔍 Scan de Portas                ║
    ║  [2] 🌐 Scan de Subdomínios           ║
    ║  [3] 🔎 Bruteforce DNS COMPLETO       ║
    ║  [4] 🚨 Scan de VULNERABILIDADES      ║
    ║  [5] 💥 EXPLOIT Automático            ║
    ║  [6] 🔐 BRUTEFORCE WEB                ║
    ║  [7] ⚡ BRUTEFORCE SSH/FTP             ║
    ║  [8] ⚡ Gerar Script Metasploit        ║
    ║  [9] 🎯 Scan COMPLETO (Tudo)          ║
    ║  [10] 🛡️ Teste de Resiliência DDoS    ║
    ║  [11] ❌ Sair                         ║
    ╚═══════════════════════════════════════╝
        """)

    def get_target(self):
        if not self.target:
            self.target = input("\n🎯 Digite o alvo (IP/URL): ").strip()
        return self.target

    def port_scan_menu(self):
        print("\n" + "="*50)
        print("           SCAN DE PORTAS")
        print("="*50)
        
        target = self.get_target()
        ports = input("[?] Portas (ex: 1-1000,80,443) [1-1000]: ").strip() or "1-1000"
        threads = input("[?] Threads [100]: ").strip() or "100"
        
        print(f"\n[*] Iniciando scan em {target}...")
        
        try:
            scanner = PortScanner(target)
            self.open_ports = scanner.scan_ports(ports, int(threads))
            
            if self.open_ports:
                print(f"\n[+] {len(self.open_ports)} portas abertas encontradas:")
                for port, service in self.open_ports:
                    print(f"    ✅ {port}/tcp - {service}")
            else:
                print("[-] Nenhuma porta aberta encontrada.")
                
        except Exception as e:
            print(f"[-] Erro: {e}")

    def subdomain_scan_menu(self):
        print("\n" + "="*50)
        print("         SCAN DE SUBDOMÍNIOS")
        print("="*50)
        
        target = self.get_target()
        wordlist = input("[?] Wordlist [wordlists/sub.txt]: ").strip() or "wordlists/sub.txt"
        threads = input("[?] Threads [50]: ").strip() or "50"
        
        print(f"\n[*] Iniciando scan de subdomínios em {target}...")
        
        try:
            scanner = SubdomainScanner(target, wordlist)
            subdomains = scanner.scan(int(threads))
            
            if subdomains:
                print(f"\n[+] {len(subdomains)} subdomínios encontrados:")
                for subdomain in subdomains:
                    print(f"    🌐 {subdomain}")
            else:
                print("[-] Nenhum subdomínio encontrado.")
                
        except Exception as e:
            print(f"[-] Erro: {e}")

    def dns_bruteforce_menu(self):
        print("\n" + "="*50)
        print("           BRUTEFORCE DNS COMPLETO")
        print("="*50)
        
        target = self.get_target()
        wordlist = input("[?] Wordlist [wordlists/dns.txt]: ").strip() or "wordlists/dns.txt"
        threads = input("[?] Threads [50]: ").strip() or "50"
        scan_paths = input("[?] Scan paths também? (s/n) [s]: ").strip().lower() or "s"
        
        scan_paths_bool = scan_paths == 's'
        
        print(f"\n[*] Iniciando bruteforce DNS COMPLETO em {target}...")
        
        try:
            dns = DNSBruteforce(target)
            results = dns.bruteforce(wordlist, int(threads), scan_paths_bool)
            
            # Coleta URLs de login para sugestões futuras
            if scan_paths_bool and hasattr(dns, 'found_paths'):
                for url, status, size in dns.found_paths:
                    if any(login_keyword in url.lower() for login_keyword in ['login', 'admin', 'painel', 'signin']):
                        self.login_urls.append(url)
            
            print("\n" + "="*50)
            print("          RESULTADOS DNS COMPLETOS")
            print("="*50)
            
            if results:
                for result_type, values in results.items():
                    if values:
                        print(f"\n[+] {result_type}:")
                        for value in values[:10]:
                            print(f"    ✅ {value}")
                        if len(values) > 10:
                            print(f"    ... e mais {len(values) - 10} resultados")
            else:
                print("[-] Nenhum resultado encontrado.")
                    
        except Exception as e:
            print(f"[-] Erro: {e}")

    def vulnerability_scan_menu(self):
        if not self.open_ports:
            print("[-] Execute o scan de portas primeiro!")
            return
        
        print("\n" + "="*50)
        print("         SCAN DE VULNERABILIDADES")
        print("="*50)
        
        target = self.get_target()
        
        print(f"[*] Analisando vulnerabilidades em {target}...")
        
        try:
            vuln_scanner = VulnerabilityScanner(target)
            self.vulnerabilities = vuln_scanner.scan_ports(self.open_ports)
            
            if self.vulnerabilities:
                print(f"\n[!] {len(self.vulnerabilities)} VULNERABILIDADES ENCONTRADAS:")
                for vuln in self.vulnerabilities:
                    print(f"    💀 {vuln}")
            else:
                print("[+] Nenhuma vulnerabilidade crítica encontrada")
                
        except Exception as e:
            print(f"[-] Erro: {e}")

    def exploit_menu(self):
        if not self.vulnerabilities:
            print("[-] Execute o scan de vulnerabilidades primeiro!")
            return

        print("\n" + "="*50)
        print("           EXPLOIT AVANÇADO POR VERSÃO")
        print("="*50)

        target = self.get_target()

        print(f"[*] Executando exploits ESPECÍFICOS por versão em {target}...")
        
        try:
            exploiter = Exploiter(target)
            
            # Passa as versões detectadas para o exploiter
            if hasattr(self, 'vulnerability_scanner'):
                service_versions = getattr(self.vulnerability_scanner, 'service_versions', {})
                exploiter.set_service_versions(service_versions)
            
            success_count = 0
            successful_exploits = []
            
            for vuln in self.vulnerabilities:
                print(f"\n[*] Analisando: {vuln}")
                success, exploit_name = exploiter.advanced_exploit(vuln)
                if success:
                    success_count += 1
                    successful_exploits.append(exploit_name)
                    print(f"[+] 💥 {exploit_name} - EXPLOIT BEM-SUCEDIDO!")
            
            # RELATÓRIO DETALHADO
            print("\n" + "="*50)
            print("           RELATÓRIO DE EXPLOITS")
            print("="*50)
            
            if success_count > 0:
                print(f"[🎉] {success_count} EXPLOITS BEM-SUCEDIDOS:")
                for i, exploit in enumerate(successful_exploits, 1):
                    print(f"    {i}. 💀 {exploit}")
            else:
                print(f"[😞] Nenhum exploit funcionou automaticamente.")
                    
        except Exception as e:
            print(f"[-] Erro: {e}")

    def web_bruteforce_menu(self):
        print("\n" + "="*50)
        print("           BRUTEFORCE WEB")
        print("="*50)
        
        # Mostra sugestões se disponíveis
        if self.login_urls:
            print("[💡] URLs de login encontradas anteriormente:")
            for i, url in enumerate(self.login_urls[:5], 1):
                print(f"    {i}. {url}")
            print()
        
        target_url = input("[?] URL do formulário de login (ex: http://site.com/admin): ").strip()
        
        # Se o usuário digitar apenas número, usa a URL sugerida
        if target_url.isdigit() and self.login_urls:
            index = int(target_url) - 1
            if 0 <= index < len(self.login_urls):
                target_url = self.login_urls[index]
                print(f"[+] Usando URL sugerida: {target_url}")
        
        if not target_url:
            print("[-] URL é obrigatória!")
            return
            
        if not target_url.startswith(('http://', 'https://')):
            target_url = 'http://' + target_url
        
        threads = input("[?] Threads [10]: ").strip() or "10"
        
        print(f"\n[*] Iniciando bruteforce web em: {target_url}")
        
        try:
            from src.web_bruteforce import WebBruteforce
            web_brute = WebBruteforce(target_url)
            results = web_brute.scan_and_bruteforce(int(threads))
            
            if results:
                print(f"\n[🎉] {len(results)} CREDENCIAIS ENCONTRADAS!")
                for username, password in results:
                    print(f"    🔓 {username}:{password}")
            else:
                print("\n[🔒] Nenhuma credencial válida encontrada.")
                
        except Exception as e:
            print(f"[-] Erro: {e}")

    def ssh_ftp_bruteforce_menu(self):
        print("\n" + "="*50)
        print("           BRUTEFORCE SSH/FTP")
        print("="*50)
        
        # Mostra serviços disponíveis se encontrados
        if self.ssh_ftp_targets:
            print("[💡] Serviços SSH/FTP encontrados:")
            for i, (service, port, banner) in enumerate(self.ssh_ftp_targets[:5], 1):
                print(f"    {i}. {service} na porta {port}")
                if banner:
                    print(f"       Banner: {banner[:50]}...")
            print()
        
        target = input("[?] IP/Alvo: ").strip() or self.target
        port = input("[?] Porta [22]: ").strip() or "22"
        service_type = input("[?] Tipo (ssh/ftp/auto) [auto]: ").strip().lower() or "auto"
        
        if service_type == "auto":
            # Detecta automaticamente pelo banner
            for svc, svc_port, banner in self.ssh_ftp_targets:
                if svc_port == int(port):
                    service_type = svc
                    print(f"[+] Serviço detectado: {service_type}")
                    break
            if service_type == "auto":
                service_type = "ssh" if port == "22" else "ftp"
        
        threads = input("[?] Threads [5]: ").strip() or "5"
        
        print(f"\n[*] Iniciando bruteforce {service_type.upper()} em {target}:{port}...")
        
        try:
            brute = SSH_FTP_Bruteforce(target, int(port), service_type)
            results = brute.bruteforce(int(threads))
            
            if results:
                print(f"\n[🎉] CREDENCIAIS {service_type.upper()} ENCONTRADAS!")
                for username, password in results:
                    print(f"    🔓 {username}:{password}")
            else:
                print(f"\n[🔒] Nenhuma credencial {service_type.upper()} válida encontrada.")
                
        except Exception as e:
            print(f"[-] Erro: {e}")

    def metasploit_menu(self):
        if not self.vulnerabilities:
            print("[-] Execute o scan de vulnerabilidades primeiro!")
            return
        
        print("\n" + "="*50)
        print("          METASPLOIT INTEGRATION")
        print("="*50)
        
        target = self.get_target()
        
        print(f"[*] Gerando script Metasploit para {target}...")
        
        try:
            msf = MetasploitIntegration(target)
            script_path = msf.generate_metasploit_script(self.vulnerabilities)
            
            print(f"[+] Script salvo: {script_path}")
            
            run = input("[?] Executar Metasploit agora? (s/n): ").strip().lower()
            if run == 's':
                msf.run_metasploit(script_path)
            else:
                print(f"[*] Execute manualmente depois com: msfconsole -r {script_path}")
                
        except Exception as e:
            print(f"[-] Erro: {e}")

    def ddos_analysis_menu(self):
        print("\n" + "="*60)
        print("       ANÁLISE DE RESILIÊNCIA DDoS")
        print("="*60)
        print("⚠️  FERRAMENTA EDUCACIONAL - USE COM AUTORIZAÇÃO")
        print("="*60)
        
        target = input("[?] URL do alvo (ex: http://site.com): ").strip()
        
        if not target.startswith(('http://', 'https://')):
            target = 'http://' + target
        
        duration = input("[?] Duração do teste em segundos [30]: ").strip() or "30"
        threads = input("[?] Número de threads [20]: ").strip() or "20"
        
        try:
            from src.ddos_analyzer import DDOSAnalyzer
            analyzer = DDOSAnalyzer(target)
            analyzer.analyze_server_resilience(int(duration), int(threads))
        except Exception as e:
            print(f"[-] Erro durante análise: {e}")

    def detect_ssh_ftp_services(self):
        """Detecta serviços SSH e FTP automaticamente"""
        self.ssh_ftp_targets = []
        
        for port, service in self.open_ports:
            if service in ['SSH', 'FTP']:
                # Tenta pegar banner para detecção mais precisa
                try:
                    import socket
                    sock = socket.socket()
                    sock.settimeout(3)
                    sock.connect((self.target, port))
                    banner = sock.recv(1024).decode('utf-8', errors='ignore')
                    sock.close()
                    
                    self.ssh_ftp_targets.append((service.lower(), port, banner.strip()))
                except:
                    self.ssh_ftp_targets.append((service.lower(), port, "Banner não disponível"))

    def full_scan_menu(self):
        print("\n" + "="*50)
        print("             SCAN COMPLETO")
        print("="*50)
        
        target = self.get_target()
        
        print(f"[*] SCAN COMPLETO INICIADO EM: {target}")
        print("[*] Isso pode levar vários minutos...")
        
        try:
            # Reset das listas
            self.login_urls = []
            self.ssh_ftp_targets = []
            
            # 1. Scan de Portas
            print("\n[1/8] 🔍 Scan de Portas...")
            scanner = PortScanner(target)
            self.open_ports = scanner.scan_ports("1-1000", 100)
            
            if not self.open_ports:
                print("[-] Nenhuma porta aberta encontrada. Parando scan.")
                return
            
            # 2. Detecção de serviços SSH/FTP
            print("\n[2/8] 🔍 Detectando SSH/FTP...")
            self.detect_ssh_ftp_services()
            
            # 3. Scan de Subdomínios
            print("\n[3/8] 🌐 Scan de Subdomínios...")
            sub_scanner = SubdomainScanner(target)
            subdomains = sub_scanner.scan(50)
            
            # 4. Bruteforce DNS
            print("\n[4/8] 🔎 Bruteforce DNS...")
            dns = DNSBruteforce(target)
            dns_results = dns.bruteforce(scan_paths=True)
            
            # Coleta URLs de login
            if hasattr(dns, 'found_paths'):
                for url, status, size in dns.found_paths:
                    if any(login_keyword in url.lower() for login_keyword in ['login', 'admin', 'painel', 'signin', 'auth']):
                        self.login_urls.append(url)
            
            # 5. Scan de Vulnerabilidades
            print("\n[5/8] 🚨 Scan de Vulnerabilidades AVANÇADO...")
            vuln_scanner = VulnerabilityScanner(target)
            self.vulnerabilities = vuln_scanner.scan_ports(self.open_ports)
            
            # 6. Exploits Avançados
            success_count = 0
            if self.vulnerabilities:
                print("\n[6/8] 💥 Executando Exploits Específicos...")
                exploiter = Exploiter(target)
                for vuln in self.vulnerabilities:
                    success, exploit_name = exploiter.advanced_exploit(vuln)
                    if success:
                        success_count += 1
            
            # 7. Sugestões de Bruteforce Web
            print("\n[7/8] 🔐 ANALISANDO BRUTEFORCE...")
            if self.login_urls:
                print(f"[💡] {len(self.login_urls)} URLs DE LOGIN ENCONTRADAS!")
                print("[🎯] Use a opção 6 para bruteforce web:")
                for i, url in enumerate(self.login_urls[:5], 1):
                    print(f"    {i}. {url}")
            
            # 8. Sugestões de Bruteforce SSH/FTP
            if self.ssh_ftp_targets:
                print(f"\n[💡] {len(self.ssh_ftp_targets)} SERVIÇOS SSH/FTP ENCONTRADOS!")
                print("[🎯] Use a opção 7 para bruteforce SSH/FTP:")
                for service, port, banner in self.ssh_ftp_targets:
                    print(f"    🔓 {service.upper()} na porta {port}")
                    if banner and banner != "Banner não disponível":
                        print(f"       Banner: {banner}")
            
            print("\n" + "="*50)
            print("[+] 🎉 SCAN COMPLETO FINALIZADO!")
            print("="*50)
            print(f"📊 RESUMO:")
            print(f"   → Portas abertas: {len(self.open_ports)}")
            print(f"   → Subdomínios: {len(subdomains)}")
            print(f"   → URLs de login: {len(self.login_urls)}")
            print(f"   → Serviços SSH/FTP: {len(self.ssh_ftp_targets)}")
            print(f"   → Vulnerabilidades: {len(self.vulnerabilities)}")
            if self.vulnerabilities:
                print(f"   → Exploits bem-sucedidos: {success_count}")
            
            # DESTACA próximos passos
            if self.login_urls or self.ssh_ftp_targets:
                print(f"\n🎯 PRÓXIMOS PASSOS SUGERIDOS:")
                if self.login_urls:
                    print("   • Use OPÇÃO 6 para Bruteforce Web")
                if self.ssh_ftp_targets:
                    print("   • Use OPÇÃO 7 para Bruteforce SSH/FTP")
            
        except Exception as e:
            print(f"[-] Erro durante scan completo: {e}")

    def main_loop(self):
        while True:
            self.clear_screen()
            self.display_banner()
            
            choice = input("\n[?] Escolha uma opção (1-11): ").strip()
            
            if choice == "1":
                self.port_scan_menu()
            elif choice == "2":
                self.subdomain_scan_menu()
            elif choice == "3":
                self.dns_bruteforce_menu()
            elif choice == "4":
                self.vulnerability_scan_menu()
            elif choice == "5":
                self.exploit_menu()
            elif choice == "6":
                self.web_bruteforce_menu()
            elif choice == "7":
                self.ssh_ftp_bruteforce_menu()
            elif choice == "8":
                self.metasploit_menu()
            elif choice == "9":
                self.full_scan_menu()
            elif choice == "10":  # NOVA OPÇÃO DDoS Analysis
                self.ddos_analysis_menu()
            elif choice == "11":  # AGORA É SAIR
                print("\n👋 Saindo... Até logo!")
                break
            else:
                print("[-] Opção inválida!")
            
            input("\n↵ Pressione Enter para continuar...")
