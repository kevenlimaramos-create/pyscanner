#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket
import threading
from concurrent.futures import ThreadPoolExecutor

class PortScanner:
    def __init__(self, target):
        self.target = target
        self.common_services = {
            21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
            80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 
            993: "IMAPS", 995: "POP3S", 3306: "MySQL", 3389: "RDP",
            5432: "PostgreSQL", 5900: "VNC", 6379: "Redis", 27017: "MongoDB"
        }

    def parse_ports(self, ports_str):
        ports = []
        if '-' in ports_str:
            start, end = map(int, ports_str.split('-'))
            ports = list(range(start, end + 1))
        else:
            ports = [int(p) for p in ports_str.split(',')]
        return ports

    def get_service_name(self, port):
        return self.common_services.get(port, "Desconhecido")

    def scan_port(self, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((self.target, port))
            sock.close()
            if result == 0:
                service = self.get_service_name(port)
                return port, service
        except:
            pass
        return None

    def scan_ports(self, ports="1-1000", threads=100):
        port_list = self.parse_ports(ports)
        open_ports = []
        lock = threading.Lock()

        print(f"[*] Escaneando {len(port_list)} portas em {self.target}...")

        def worker(port):
            result = self.scan_port(port)
            if result:
                with lock:
                    open_ports.append(result)
                print(f"[+] Porta {result[0]}/tcp aberta - {result[1]}")

        with ThreadPoolExecutor(max_workers=threads) as executor:
            executor.map(worker, port_list)

        print(f"[+] Scan finalizado. {len(open_ports)} portas abertas.")
        return open_ports
