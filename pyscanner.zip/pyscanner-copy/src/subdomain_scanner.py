#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket
import threading
from concurrent.futures import ThreadPoolExecutor
import os

class SubdomainScanner:
    def __init__(self, domain, wordlist_path="wordlists/sub.txt"):
        self.domain = domain
        self.wordlist_path = wordlist_path
        self.found_subdomains = []
        self.lock = threading.Lock()

    def load_wordlist(self):
        try:
            with open(self.wordlist_path, 'r') as f:
                return [line.strip() for line in f if line.strip()]
        except:
            return ["www", "mail", "ftp", "admin", "api", "blog", "shop"]

    def check_subdomain(self, subdomain):
        full_domain = f"{subdomain}.{self.domain}"
        try:
            ip = socket.gethostbyname(full_domain)
            with self.lock:
                self.found_subdomains.append(full_domain)
            print(f"[+] Subdomínio: {full_domain} -> {ip}")
        except:
            pass

    def scan(self, threads=50):
        wordlist = self.load_wordlist()
        print(f"[*] Testando {len(wordlist)} subdomínios...")

        with ThreadPoolExecutor(max_workers=threads) as executor:
            executor.map(self.check_subdomain, wordlist)

        print(f"[+] Scan finalizado. {len(self.found_subdomains)} subdomínios encontrados.")
        return self.found_subdomains
