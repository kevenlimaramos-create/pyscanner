#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import datetime
from typing import List, Tuple

class ReportGenerator:
    def __init__(self, target: str, open_ports: List[Tuple[int, str]], vulnerabilities: List[str]):
        self.target = target
        self.open_ports = open_ports
        self.vulnerabilities = vulnerabilities
        self.timestamp = datetime.datetime.now().isoformat()
    
    def generate_html(self, filename: str):
        """Gera relatório em HTML"""
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Relatório PyScanner - {self.target}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background: #2c3e50; color: white; padding: 20px; }}
                .section {{ margin: 20px 0; padding: 15px; border: 1px solid #ddd; }}
                .vulnerability {{ color: #e74c3c; }}
                .port {{ color: #27ae60; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Relatório de Segurança</h1>
                <p>Alvo: {self.target} | Data: {self.timestamp}</p>
            </div>
            
            <div class="section">
                <h2>Resumo</h2>
                <p>Portas abertas: {len(self.open_ports)}</p>
                <p>Vulnerabilidades encontradas: {len(self.vulnerabilities)}</p>
            </div>
            
            <div class="section">
                <h2>Portas Abertas</h2>
                <ul>
        """
        
        for port, service in self.open_ports:
            html_content += f'<li class="port">Porta {port}/tcp - {service}</li>'
        
        html_content += """
                </ul>
            </div>
        """
        
        if self.vulnerabilities:
            html_content += """
            <div class="section">
                <h2>Vulnerabilidades</h2>
                <ul>
            """
            
            for vuln in self.vulnerabilities:
                html_content += f'<li class="vulnerability">{vuln}</li>'
            
            html_content += """
                </ul>
            </div>
            """
        
        html_content += """
            <div class="section">
                <p><em>Relatório gerado por PyScanner - Desenvolvido por whatcomes</em></p>
            </div>
        </body>
        </html>
        """
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html_content)
    
    def generate_json(self, filename: str):
        """Gera relatório em JSON"""
        report = {
            "target": self.target,
            "timestamp": self.timestamp,
            "open_ports": [{"port": port, "service": service} for port, service in self.open_ports],
            "vulnerabilities": self.vulnerabilities,
            "summary": {
                "total_ports": len(self.open_ports),
                "total_vulnerabilities": len(self.vulnerabilities)
            }
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
    
    def generate(self, filename: str):
        """Gera relatório no formato apropriado"""
        if filename.endswith('.html'):
            self.generate_html(filename)
        elif filename.endswith('.json'):
            self.generate_json(filename)
        else:
            self.generate_txt(filename)
    
    def generate_txt(self, filename: str):
        """Gera relatório em texto simples"""
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"Relatório PyScanner - Desenvolvido por whatcomes\n")
            f.write(f"Alvo: {self.target}\n")
            f.write(f"Data: {self.timestamp}\n")
            f.write("=" * 50 + "\n\n")
            
            f.write("PORTAS ABERTAS:\n")
            for port, service in self.open_ports:
                f.write(f"  {port}/tcp - {service}\n")
            
            f.write(f"\nTotal de portas abertas: {len(self.open_ports)}\n\n")
            
            if self.vulnerabilities:
                f.write("VULNERABILIDADES ENCONTRADAS:\n")
                for vuln in self.vulnerabilities:
                    f.write(f"  [!] {vuln}\n")
                f.write(f"\nTotal de vulnerabilidades: {len(self.vulnerabilities)}\n")
