#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import time
import threading
import requests
from concurrent.futures import ThreadPoolExecutor
import psutil
import socket

class DDOSAnalyzer:
    """
    ANALISADOR DE RESILIÊNCIA DDoS - APENAS PARA TESTES AUTORIZADOS
    Ferramenta educacional para análise de performance e segurança
    """
    
    def __init__(self, target):
        self.target = target
        self.results = {
            'requests_sent': 0,
            'successful_responses': 0,
            'failed_responses': 0,
            'average_response_time': 0,
            'start_time': 0,
            'end_time': 0
        }
        
    def legal_warning(self):
        print("\n" + "!"*60)
        print("⚠️  AVISO LEGAL IMPORTANTE")
        print("!"*60)
        print("❌ ESTA FERRAMENTA É APENAS PARA FINS EDUCACIONAIS")
        print("❌ USE APENAS EM SISTEMAS PRÓPRIOS OU COM AUTORIZAÇÃO")
        print("❌ ATAQUES DDoS SÃO CRIMINOSOS SEM PERMISSÃO")
        print("!"*60)
        
        confirm = input("\n✅ Você tem autorização para testar este alvo? (s/N): ").strip().lower()
        return confirm == 's'
    
    def single_request(self, thread_id):
        """Faz uma única requisição HTTP para teste de carga"""
        try:
            start_time = time.time()
            response = requests.get(
                self.target, 
                timeout=10,
                headers={'User-Agent': f'PyScanner-Stress-Test-{thread_id}'}
            )
            end_time = time.time()
            
            self.results['requests_sent'] += 1
            if response.status_code == 200:
                self.results['successful_responses'] += 1
            else:
                self.results['failed_responses'] += 1
                
            return end_time - start_time
            
        except Exception as e:
            self.results['failed_responses'] += 1
            self.results['requests_sent'] += 1
            return None
    
    def analyze_server_resilience(self, duration=60, threads=50):
        """
        Teste controlado de resiliência do servidor
        """
        if not self.legal_warning():
            print("[-] Teste cancelado por questões legais.")
            return
        
        print(f"\n[*] Iniciando análise de resiliência em: {self.target}")
        print(f"[*] Duração: {duration} segundos")
        print(f"[*] Threads: {threads}")
        print("[*] Este é um TESTE CONTROLADO para fins educacionais\n")
        
        self.results['start_time'] = time.time()
        response_times = []
        
        try:
            with ThreadPoolExecutor(max_workers=threads) as executor:
                start_time = time.time()
                
                while time.time() - start_time < duration:
                    futures = [
                        executor.submit(self.single_request, i) 
                        for i in range(threads)
                    ]
                    
                    for future in futures:
                        result = future.result()
                        if result:
                            response_times.append(result)
                    
                    # Exibir progresso
                    elapsed = time.time() - start_time
                    print(f"\r[*] Progresso: {elapsed:.1f}s / {duration}s - Requests: {self.results['requests_sent']}", end="")
                    time.sleep(0.1)
                    
        except KeyboardInterrupt:
            print("\n[!] Teste interrompido pelo usuário")
        
        self.results['end_time'] = time.time()
        
        if response_times:
            self.results['average_response_time'] = sum(response_times) / len(response_times)
        
        self.generate_report()
    
    def generate_report(self):
        """Gera relatório detalhado da análise"""
        total_time = self.results['end_time'] - self.results['start_time']
        rps = self.results['requests_sent'] / total_time if total_time > 0 else 0
        
        print("\n\n" + "="*60)
        print("📊 RELATÓRIO DE ANÁLISE DE RESILIÊNCIA")
        print("="*60)
        print(f"🎯 Alvo: {self.target}")
        print(f"⏱️  Tempo total: {total_time:.2f} segundos")
        print(f"📨 Requests enviados: {self.results['requests_sent']}")
        print(f"✅ Responses bem-sucedidas: {self.results['successful_responses']}")
        print(f"❌ Responses com falha: {self.results['failed_responses']}")
        print(f"🚀 Requests por segundo: {rps:.2f}")
        print(f"⏳ Tempo médio de resposta: {self.results['average_response_time']:.2f}s")
        
        # Análise de segurança
        success_rate = (self.results['successful_responses'] / self.results['requests_sent']) * 100
        print(f"📈 Taxa de sucesso: {success_rate:.1f}%")
        
        print("\n🛡️  RECOMENDAÇÕES DE SEGURANÇA:")
        if rps > 100:
            print("   • ⚠️  Considere implementar WAF (Web Application Firewall)")
            print("   • ⚠️  Configure rate limiting no servidor")
            print("   • ⚠️  Use CDN para distribuir carga")
        elif success_rate < 50:
            print("   • 🔴 Servidor mostrou baixa resiliência - otimizações necessárias")
        else:
            print("   • 🟢 Servidor mostrou boa resiliência à carga")
        
        print("="*60)

def check_system_resources():
    """Verifica recursos do sistema durante o teste"""
    cpu = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory().percent
    print(f"[*] Recursos do sistema - CPU: {cpu}% | Memória: {memory}%")
