import socket
import ssl
import requests
from typing import Dict, Any, List

class ServerAnalyzer:
    def __init__(self, target: str):
        self.target = target
        self.results = {}
    
    def get_ip_info(self) -> Dict[str, Any]:
        """Obtém informações do IP"""
        try:
            ip = socket.gethostbyname(self.target)
            hostname = socket.getfqdn(self.target)
            
            return {
                'ip': ip,
                'hostname': hostname,
                'resolved': True
            }
        except:
            return {'resolved': False}
    
    def analyze_ssl(self) -> Dict[str, Any]:
        """Analisa certificado SSL"""
        try:
            context = ssl.create_default_context()
            with socket.create_connection((self.target, 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=self.target) as ssock:
                    cert = ssock.getpeercert()
                    cipher = ssock.cipher()
                    
                    return {
                        'version': cipher[1],
                        'cipher': cipher[0],
                        'valid': True
                    }
        except:
            return {'valid': False}
    
    def get_http_headers(self) -> Dict[str, Any]:
        """Obtém headers HTTP"""
        try:
            response = requests.get(f"http://{self.target}", timeout=5, verify=False)
            return dict(response.headers)
        except:
            try:
                response = requests.get(f"https://{self.target}", timeout=5, verify=False)
                return dict(response.headers)
            except:
                return {}
    
    def check_technologies(self) -> List[str]:
        """Detecta tecnologias utilizadas"""
        technologies = []
        headers = self.get_http_headers()
        
        server = headers.get('Server', '').lower()
        if 'apache' in server:
            technologies.append('Apache')
        elif 'nginx' in server:
            technologies.append('Nginx')
        elif 'iis' in server:
            technologies.append('IIS')
        
        powered_by = headers.get('X-Powered-By', '').lower()
        if 'php' in powered_by:
            technologies.append('PHP')
        elif 'asp.net' in powered_by:
            technologies.append('ASP.NET')
        
        return technologies
    
    def comprehensive_scan(self) -> Dict[str, Any]:
        """Executa análise completa do servidor"""
        print(f"[*] Iniciando análise completa do servidor {self.target}")
        
        self.results = {
            'target': self.target,
            'ip_info': self.get_ip_info(),
            'ssl_info': self.analyze_ssl(),
            'http_headers': self.get_http_headers(),
            'technologies': self.check_technologies(),
            'timestamp': str(__import__('datetime').datetime.now())
        }
        
        return self.results
