#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket
import threading
from concurrent.futures import ThreadPoolExecutor
import os
import requests
from urllib.parse import urljoin, urlparse
import urllib3
import re

# Suprimir warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class DNSBruteforce:
    def __init__(self, domain):
        self.domain = domain
        self.found_subdomains = []
        self.found_paths = []  # IMPORTANTE: manter esta linha
        self.session = requests.Session()
        self.session.verify = False

    def load_wordlist(self, wordlist_path):
        """Carrega wordlist ou usa lista expansiva padrão"""
        try:
            with open(wordlist_path, 'r') as f:
                return [line.strip() for line in f if line.strip()]
        except:
            return self.get_extensive_wordlist()

    def get_extensive_wordlist(self):
        """Retorna wordlist muito mais completa"""
        base_subs = [
            'www', 'mail', 'ftp', 'admin', 'api', 'blog', 'shop', 'cdn', 
            'dev', 'test', 'staging', 'webmail', 'smtp', 'pop', 'imap', 
            'ns1', 'ns2', 'dns1', 'dns2', 'web', 'app', 'apps', 'mobile', 
            'm', 'email', 'forum', 'support', 'help', 'docs', 'wiki', 
            'store', 'payment', 'checkout', 'account', 'user', 'dashboard',
            'panel', 'cpanel', 'whm', 'control', 'manager', 'server', 
            'cloud', 'storage', 'backup', 'db', 'database', 'sql', 'mysql',
            'postgres', 'redis', 'cache', 'proxy', 'vpn', 'ssh', 'sftp',
            'git', 'svn', 'jenkins', 'docker', 'kubernetes', 'auth', 'oauth',
            'sso', 'openid', 'ldap', 'ad', 'exchange', 'sharepoint', 'teams',
            'skype', 'zoom', 'meet', 'webex', 'jitsi', 'video', 'audio',
            'stream', 'live', 'tv', 'radio', 'music', 'image', 'photo',
            'files', 'download', 'upload', 'cdn', 'assets', 'static', 'media',
            'public', 'private', 'secure', 'ssl', 'tls', 'https', 'http2',
            'login', 'admin', 'dashboard', 'portal', 'config', 'backup',
            'test', 'dev', 'staging', 'api', 'rest', 'graphql'
        ]
        
        # Adiciona prefixos e sufixos
        prefixes = ['', 'api-', 'web-', 'mobile-', 'admin-', 'dev-', 'test-', 'staging-']
        suffixes = ['', '-api', '-web', '-admin', '-dev', '-test', '-staging']
        
        expanded_list = []
        for sub in base_subs:
            for prefix in prefixes:
                for suffix in suffixes:
                    expanded_list.append(f"{prefix}{sub}{suffix}")
        
        # Remove duplicatas e retorna
        return list(set(expanded_list))

    def check_subdomain(self, subdomain):
        """Verifica se subdomínio existe"""
        full_domain = f"{subdomain}.{self.domain}"
        try:
            ip = socket.gethostbyname(full_domain)
            self.found_subdomains.append((full_domain, ip))
            print(f"[+] 🌐 Subdomínio: {full_domain} -> {ip}")
            return True
        except:
            return False

    def get_common_paths(self):
        """Retorna paths comuns para testar - LISTA OTIMIZADA"""
        return [
            # Paths de administração (ALTA PRIORIDADE)
            'login', 'admin', 'administrator', 'dashboard', 'panel', 
            'wp-admin', 'wordpress', 'cpanel', 'whm', 'webadmin',
            
            # Paths de autenticação
            'signin', 'signup', 'register', 'auth', 'authentication',
            'oauth', 'sso', 'logout',
            
            # Paths de usuário
            'user', 'users', 'account', 'accounts', 'profile',
            
            # APIs
            'api', 'api/v1', 'api/v2', 'rest', 'graphql',
            
            # Arquivos sensíveis
            '.git', '.env', 'config.php', 'wp-config.php',
            'robots.txt', '.htaccess', '.htpasswd',
            
            # Paths específicos do Brasil
            'painel', 'paineladm', 'administracao', 'configuracao',
            'usuario', 'sistema', 'acesso'
        ]

    def is_meaningful_response(self, response, original_url):
        """Verifica se a resposta é significativa (não é página genérica)"""
        try:
            content = response.text.lower()
            content_length = len(response.content)
            
            # 1. Ignora respostas muito pequenas
            if content_length < 100:
                return False
            
            # 2. Verifica se é página de erro genérica
            error_indicators = [
                'page not found', '404', 'not found', 'error',
                'página não encontrada', 'não encontrada'
            ]
            
            if any(indicator in content for indicator in error_indicators):
                return False
            
            # 3. Verifica se é redirecionamento para página principal
            if response.url != original_url and 'login' not in response.url.lower():
                # Se redirecionou para uma página diferente, pode ser significativo
                return True
            
            # 4. Verifica por elementos específicos de páginas de login/admin
            login_indicators = [
                'password', 'username', 'login', 'sign in', 'entrar',
                'email', 'senha', 'usuário', 'acessar'
            ]
            
            admin_indicators = [
                'dashboard', 'panel', 'admin', 'administrator',
                'painel', 'controle', 'gerenciar'
            ]
            
            # 5. Se contém elementos de login/admin, é significativo
            if any(indicator in content for indicator in login_indicators + admin_indicators):
                return True
            
            # 6. Compara com a página principal (se disponível)
            try:
                main_page_response = self.session.get(original_url.rsplit('/', 1)[0] + '/', timeout=3)
                if response.text == main_page_response.text:
                    return False  # É a mesma página principal
            except:
                pass
            
            # 7. Se passou por todos os filtros, considera significativo
            return True
            
        except:
            return False

    def test_http_path(self, base_url, path):
        """Testa se um path HTTP existe - COM FILTROS INTELIGENTES"""
        try:
            url = urljoin(base_url, path)
            original_url = url
            
            response = self.session.get(
                url, 
                timeout=3, 
                verify=False, 
                allow_redirects=True,
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            )
            
            # FILTROS INTELIGENTES - Só mostra se for significativo
            if self.is_meaningful_response(response, original_url):
                content_length = len(response.content)
                status_emoji = "🟢" if response.status_code == 200 else "🟡"
                
                # Verifica se é uma página de login/admin (ALTA PRIORIDADE)
                is_login_page = any(login_keyword in url.lower() for login_keyword in 
                                  ['login', 'admin', 'auth', 'signin', 'painel'])
                
                if is_login_page:
                    status_emoji = "🎯"  # Destaque especial para páginas de login
                
                self.found_paths.append((url, response.status_code, content_length))
                print(f"{status_emoji} Path: {url} [{response.status_code}] ({content_length} bytes)")
                return True
                
        except requests.exceptions.Timeout:
            pass
        except requests.exceptions.ConnectionError:
            pass
        except Exception as e:
            pass
            
        return False

    def scan_common_paths(self, subdomain):
        """Escaneia paths comuns em um subdomínio - VERSÃO OTIMIZADA"""
        protocols = ['http', 'https']
        paths = self.get_common_paths()
        
        for protocol in protocols:
            base_url = f"{protocol}://{subdomain}.{self.domain}/"
            print(f"[*] Scan paths em {base_url}")
            
            found_count = 0
            for path in paths:  # Testa apenas paths prioritários
                if self.test_http_path(base_url, path):
                    found_count += 1
            
            if found_count > 0:
                print(f"[+] Encontrados {found_count} paths significativos em {base_url}")
            else:
                print(f"[-] Nenhum path significativo em {base_url}")

    def bruteforce_subdomains(self, wordlist_file, threads=50):
        """Bruteforce de subdomínios com threads"""
        wordlist = self.load_wordlist(wordlist_file)
        print(f"[*] Bruteforce DNS com {len(wordlist)} entradas...")
        
        with ThreadPoolExecutor(max_workers=threads) as executor:
            executor.map(self.check_subdomain, wordlist)
        
        print(f"[+] Bruteforce finalizado. {len(self.found_subdomains)} subdomínios encontrados.")
        return self.found_subdomains

    def scan_paths_on_found_subdomains(self):
        """Escaneia paths nos subdomínios encontrados - VERSÃO RÁPIDA"""
        if not self.found_subdomains:
            return
            
        print(f"[*] Escaneando paths prioritários em {len(self.found_subdomains)} subdomínios...")
        
        # Foca apenas nos subdomínios mais promissores
        promising_subdomains = []
        for subdomain, ip in self.found_subdomains:
            sub_lower = subdomain.lower()
            if any(keyword in sub_lower for keyword in ['webmail', 'admin', 'login', 'mail', 'panel']):
                promising_subdomains.append((subdomain, ip))
        
        if promising_subdomains:
            print(f"[*] Focando em {len(promising_subdomains)} subdomínios promissores...")
            for subdomain, ip in promising_subdomains:
                sub_part = subdomain.replace(f".{self.domain}", "")
                self.scan_common_paths(sub_part)
        else:
            # Se não encontrou subdomínios promissores, testa apenas os primeiros 3
            print(f"[*] Testando os primeiros 3 subdomínios...")
            for subdomain, ip in self.found_subdomains[:3]:
                sub_part = subdomain.replace(f".{self.domain}", "")
                self.scan_common_paths(sub_part)

    def direct_path_scan(self):
        """Escaneia paths diretamente no domínio principal - VERSÃO RÁPIDA"""
        print(f"[*] Escaneando paths prioritários em {self.domain}...")
        
        protocols = ['http', 'https']
        paths = self.get_common_paths()
        
        total_found = 0
        for protocol in protocols:
            base_url = f"{protocol}://{self.domain}/"
            print(f"[*] Scan direto em {base_url}")
            
            found_count = 0
            for path in paths:
                if self.test_http_path(base_url, path):
                    found_count += 1
                    total_found += 1
            
            if found_count > 0:
                print(f"[+] Encontrados {found_count} paths significativos em {base_url}")
        
        return total_found

    def bruteforce(self, wordlist_path="wordlists/dns.txt", threads=50, scan_paths=True):
        """Bruteforce DNS completo - VERSÃO OTIMIZADA"""
        print(f"[*] INICIANDO BRUTEFORCE DNS OTIMIZADO EM: {self.domain}")
        
        # 1. Bruteforce de subdomínios
        print("\n[1/3] 🔎 Bruteforce de subdomínios...")
        subdomains = self.bruteforce_subdomains(wordlist_path, threads)
        
        # 2. Scan de paths no domínio principal
        paths_found = 0
        if scan_paths:
            print("\n[2/3] 🔍 Scan de paths prioritários no domínio principal...")
            paths_found = self.direct_path_scan()
        
        # 3. Scan de paths nos subdomínios encontrados (SOMENTE OS PROMISSORES)
        if subdomains and scan_paths:
            print("\n[3/3] 🔍 Scan de paths em subdomínios promissores...")
            self.scan_paths_on_found_subdomains()
        
        # Compilar resultados
        results = {}
        if subdomains:
            results['SUBDOMINIOS'] = [f"{domain} -> {ip}" for domain, ip in subdomains]
        
        if self.found_paths:
            # Filtra apenas paths de login/admin para resultados
            login_paths = [f"{url} [{status}]" for url, status, _ in self.found_paths 
                          if any(keyword in url.lower() for keyword in ['login', 'admin', 'auth', 'painel'])]
            if login_paths:
                results['LOGIN_PATHS'] = login_paths
            
            # Todos os paths significativos
            all_paths = [f"{url} [{status}]" for url, status, _ in self.found_paths]
            if all_paths:
                results['ALL_PATHS'] = all_paths[:20]  # Limita a 20 resultados
        
        print(f"\n" + "="*50)
        print(f"[+] 🎯 BRUTEFORCE COMPLETO!")
        print(f"    → Subdomínios encontrados: {len(subdomains)}")
        print(f"    → Paths significativos: {len(self.found_paths)}")
        
        # Mostra apenas os paths mais importantes
        if self.found_paths:
            login_paths = [p for p in self.found_paths if any(kw in p[0].lower() for kw in ['login', 'admin', 'auth'])]
            if login_paths:
                print(f"    → Paths de login/admin: {len(login_paths)}")
                print(f"\n🎯 PATHS PARA BRUTEFORCE WEB:")
                for url, status, size in login_paths[:8]:  # Mostra até 8
                    print(f"    🔐 {url}")
        
        print("="*50)
        
        return results
