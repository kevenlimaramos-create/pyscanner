# PyScanner 🛡️

Ferramenta completa de pentest desenvolvida em Python por **whatcomes**.

## 🚀 Funcionalidades

- ✅ Scan de portas com multithreading
- ✅ Scanner de subdomínios com wordlist
- ✅ Bruteforce DNS
- ✅ Detecção de vulnerabilidades
- ✅ Exploits automáticos
- ✅ Integração com Metasploit
- ✅ Interface interativa e linha de comando

## 📦 Instalação

```bash
python install.py
