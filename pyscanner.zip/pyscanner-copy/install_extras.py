#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os

def create_password_files():
    """Cria arquivos de senhas básicos se não existirem"""
    os.makedirs("wordlists", exist_ok=True)
    
    # Senhas básicas para SSH/FTP
    passwords = [
        '123456', 'password', '12345678', 'qwerty', '123456789',
        '12345', '1234', '111111', '1234567', 'dragon',
        # ... (lista completa do código anterior)
    ]
    
    with open("wordlists/passwords.txt", "w") as f:
        for pwd in passwords:
            f.write(pwd + "\n")
    
    print("[+] wordlists/passwords.txt criado com sucesso!")
    print("[💡] Para melhor resultado, baixe rockyou.txt e coloque em wordlists/")
    print("[💡] Download: https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt")

if __name__ == "__main__":
    create_password_files()
