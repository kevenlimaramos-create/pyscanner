#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PyScanner - Menu Interativo
Desenvolvido por whatcomes
"""

from src.menu import InteractiveMenu

def main():
    try:
        menu = InteractiveMenu()
        menu.main_loop()
    except KeyboardInterrupt:
        print("\n\n👋 Programa interrompido pelo usuário")
    except Exception as e:
        print(f"\n❌ Erro: {e}")

if __name__ == "__main__":
    main()
