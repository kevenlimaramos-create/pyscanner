#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PyScanner - Linha de Comando
Desenvolvido por whatcomes
"""

import argparse
from src.scanner import PortScanner

def main():
    parser = argparse.ArgumentParser(description='PyScanner - Ferramenta de Pentest')
    parser.add_argument('target', help='Alvo (IP ou domínio)')
    parser.add_argument('-p', '--ports', default='1-1000', help='Portas para scan')
    parser.add_argument('-t', '--threads', type=int, default=100, help='Número de threads')
    
    args = parser.parse_args()
    
    print(f"🎯 Scan iniciado em: {args.target}")
    scanner = PortScanner(args.target)
    scanner.scan_ports(args.ports, args.threads)

if __name__ == "__main__":
    main()
