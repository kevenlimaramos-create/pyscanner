#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de Instalação - PyScanner v6.0
Desenvolvido por whatcomes
"""

import os
import subprocess
import sys

def main():
    print("🐍 Instalando PyScanner v6.0...")
    print("📦 Instalando todas as dependências...")
    
    # Lista completa de dependências para PyScanner v6.0
    dependencies = [
        "requests",           # Para requisições HTTP
        "dnspython",          # Para operações DNS
        "python-whois",       # Para consulta WHOIS
        "psutil",             # NOVA: Para análise de recursos do sistema (DDoS Analyzer)
        "urllib3",            # Para manipulação de URLs
        "socket",             # Para operações de rede
        "threading",          # Para execução paralela
        "concurrent.futures"  # Para ThreadPoolExecutor
    ]
    
    print("🔧 Instalando dependências principais...")
    for dep in dependencies:
        try:
            print(f"📦 Instalando {dep}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
            print(f"✅ {dep} instalado")
        except Exception as e:
            print(f"❌ Erro ao instalar {dep}: {e}")
            print(f"💡 Tentando instalação alternativa para {dep}...")
            try:
                # Tentativa alternativa com pip3
                subprocess.check_call(["pip3", "install", dep])
                print(f"✅ {dep} instalado via pip3")
            except:
                print(f"⚠️  Não foi possível instalar {dep} automaticamente")
                print(f"💡 Instale manualmente: pip install {dep}")
    
    # Instalações específicas para sistemas Linux
    if os.name == 'posix':
        print("🐧 Detectado sistema Linux - instalando dependências adicionais...")
        linux_deps = ["python3-psutil", "python3-requests"]
        for dep in linux_deps:
            try:
                print(f"📦 Tentando instalar {dep} via apt...")
                subprocess.check_call(["sudo", "apt", "install", "-y", dep])
                print(f"✅ {dep} instalado via apt")
            except:
                print(f"⚠️  Não foi possível instalar {dep} via apt")
    
    # Criar estrutura de pastas
    print("📁 Criando estrutura de pastas...")
    folders = ["wordlists", "src", "logs", "reports"]
    
    for folder in folders:
        os.makedirs(folder, exist_ok=True)
        print(f"✅ Pasta '{folder}' criada")
    
    # Criar wordlist sub.txt
    print("📝 Criando wordlists...")
    subdomains = """www
mail
ftp
admin
api
blog
shop
cdn
dev
test
staging
webmail
smtp
pop
imap
ns1
ns2
web
app
mobile
email
portal
login
secure
cloud
storage
backup
db
database
git
ssh
vpn
proxy
cache
static
media
files
download
upload
support
help
docs
wiki
forum
chat
bot
api
rest
graphql
soap
xml
json
auth
oauth
sso
openid
ldap
ad
exchange
sharepoint
teams
skype
zoom
meet
webex
jitsi
video
audio
stream
live
tv
radio
music
image
photo
shop
store
cart
payment
checkout
invoice
billing
bank
wallet
crypto
bitcoin
ethereum
nft
ai
ml
bot
robot
iot
smart
home
office
city
car
auto
food
restaurant
cafe
pizza
burger
sushi
delivery
grocery
market
mall
sale
deal
offer
discount
coupon
gift
card
credit
debit
insurance
loan
mortgage
investment
trading
stock
forex
currency
exchange
money
transfer
payment
wallet
digital
online
web
internet
network
social
facebook
twitter
instagram
linkedin
youtube
tiktok
whatsapp
telegram
discord
slack
microsoft
google
apple
amazon
netflix
spotify
github
gitlab
jira
confluence
trello
asana
notion
dropbox
drive
icloud
mega
box
sharefile
wetransfer"""
    
    with open("wordlists/sub.txt", "w") as f:
        f.write(subdomains)
    print("✅ Wordlist 'wordlists/sub.txt' criada")
    
    # Criar wordlist dns.txt
    dns_entries = """www
mail
ftp
admin
api
blog
shop
cdn
dev
test
staging
webmail
smtp
pop
imap
ns1
ns2
dns1
dns2
web
app
apps
mobile
m
email
forum
support
help
docs
wiki
store
payment
checkout
account
user
dashboard
panel
cpanel
whm
control
manager
server
cloud
storage
backup
db
database
sql
mysql
postgres
redis
cache
proxy
vpn
ssh
ftp
sftp
git
svn
jenkins
docker
kubernetes"""
    
    with open("wordlists/dns.txt", "w") as f:
        f.write(dns_entries)
    print("✅ Wordlist 'wordlists/dns.txt' criada")
    
    # Criar wordlist para bruteforce
    common_passwords = """admin
admin123
password
password123
123456
12345678
123456789
qwerty
abc123
letmein
welcome
monkey
password1
1234567
1234567890
admin@123
Admin@123
root
toor
default
pass
pass123
test
test123
guest
guest123
user
user123
administrator
1234
12345
123456789
12345678910
senha
senha123
brasil
brazil
brasil123
brazil123"""
    
    with open("wordlists/passwords.txt", "w") as f:
        f.write(common_passwords)
    print("✅ Wordlist 'wordlists/passwords.txt' criada")
    
    # Criar arquivo requirements.txt atualizado
    requirements = """requests==2.31.0
dnspython==2.4.2
python-whois==0.8.0
psutil==5.9.5
urllib3==1.26.16"""
    
    with open("requirements.txt", "w") as f:
        f.write(requirements)
    print("✅ Arquivo 'requirements.txt' criado")
    
    # Verificar instalação
    print("\n🔍 Verificando instalação...")
    try:
        import requests
        import dns.resolver
        import psutil
        print("✅ Todas as dependências importadas com sucesso!")
    except ImportError as e:
        print(f"❌ Erro ao importar dependências: {e}")
        print("💡 Execute manualmente: pip install -r requirements.txt")
    
    print("\n🎉 INSTALAÇÃO DO PYSCANNER V6.0 CONCLUÍDA!")
    print("="*50)
    print("👉 Use: python3 interactive.py")
    print("👉 Funcionalidades disponíveis:")
    print("   🔍 Scan de Portas")
    print("   🌐 Scan de Subdomínios") 
    print("   🔎 Bruteforce DNS")
    print("   🚨 Scan de Vulnerabilidades")
    print("   💥 Exploit Automático")
    print("   🔐 Bruteforce Web")
    print("   ⚡ Bruteforce SSH/FTP")
    print("   ⚡ Gerar Script Metasploit")
    print("   🎯 Scan Completo")
    print("   🛡️  Análise de Resiliência DDoS (NOVO!)")
    print("="*50)
    print("⚠️  USE APENAS EM SISTEMAS AUTORIZADOS!")
    print("📚 Fins educacionais e testes de segurança")

if __name__ == "__main__":
    main()
